@javax.xml.bind.annotation.XmlSchema(namespace = "http://testwebservice1/")
package service;
