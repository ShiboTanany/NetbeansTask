@javax.xml.bind.annotation.XmlSchema(namespace = "http://hibernatewebservice/")
package service;
