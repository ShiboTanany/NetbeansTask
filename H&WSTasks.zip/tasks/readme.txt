two folders one for hibernate tasks and other for web services tasks 
fist hibernate folder contains 3 folders first one is a projects contains last two criteria tasks 

second project contains (naming strategy ,listeners ,interceptors)

third one(jpa with hibernate and eclipselink by changing presistance name in main ) hope jars be sent . i will send it alone with folder jars in hibernate  




second folder is about web service four tasks 
cal with pathparam  ,download(you can write link only ) ,upload  note upload and download files according to linux os 


the web service project is in maven    

you want crud with hibernate packaged as web service  .you will find it   in web service with imagelab too 

